perl docs/tool/NaturalDocs -i src/game -i src/engine -xi src/engine/external -p docs/conf -o html docs/output
